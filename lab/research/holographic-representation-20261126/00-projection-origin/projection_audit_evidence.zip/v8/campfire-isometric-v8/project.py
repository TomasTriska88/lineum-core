"""Orthographic volume reconstruction from Campfire v4's neutral opacity layers.
No 3-D field evolution is asserted. Depth distribution is a rendering model.
"""
from pathlib import Path
import argparse, json
import numpy as np
from scipy.ndimage import affine_transform

N=96; P=(77,48)

def project(alpha, layer, yaw=45., elevation=35.26438968):
    """Distribute optical depth over 37 parallel planes, project all planes."""
    y,x=np.mgrid[:N,:N].astype(np.float32); y-=P[0]; x-=P[1]
    depth=np.arange(-18,19,1,dtype=np.float32)
    # A tapered, slightly asymmetric depth envelope, constant in time.
    # Thin, curved flame sheets; a broad low bed remains independent.
    # Static depth assignment, not inferred 3-D dynamics.
    if layer=='flame':
        height=np.clip(-y/55,0,1)
        width=1.05+1.35*np.exp(-(y/10)**2)
        center=.32*x+1.65*np.sin(x/5.5+y/16)*(.4+.6*height)
    else:
        width=np.full_like(y,4.0)
        center=.22*x+1.1*np.sin(x/5.5)
    weight=np.exp(-.5*((depth[:,None,None]-center)/width)**2)
    weight/=weight.sum(axis=0)
    theta,el=np.deg2rad([yaw,elevation]); c,s=np.cos(theta),np.sin(theta); ce,se=np.cos(el),np.sin(el)
    mat=np.array([[1/ce,-se*s/(c*ce)],[0,1/c]])
    # For each plane, inverse affine map of an orthographic 3-D projection.
    offsets=[np.array([P[0]+(-P[0]+se*s*(P[1]+s*d)/c+se*c*d)/ce,P[1]-(P[1]+s*d)/c]) for d in depth]
    # Uniform framing scale about the shared fuel pivot; never crop content.
    scale=1.0 if yaw==0 and elevation==0 else .88
    offsets=[off+mat@np.array(P)*(1-1/scale) for off in offsets]
    mat=mat/scale
    out=np.empty_like(alpha)
    for i,a in enumerate(alpha):
        tau=-np.log1p(-np.minimum(a.astype(np.float32)/255,1-1e-6))
        optical=np.zeros((N,N),np.float32)
        for w,off in zip(weight,offsets):
            optical+=affine_transform(tau*w,mat,offset=off,order=1,mode='constant',cval=0,prefilter=False)
        out[i]=np.rint(255*(-np.expm1(-optical/(c*ce)**.5))).clip(0,255).astype(np.uint8)
    return out

def main(src,out):
    with np.load(src) as z: a={l:z[l][...,3] for l in ('flame','ember')}
    arrays={l:project(v,l) for l,v in a.items()}
    # White straight alpha. Full source timing preserved for shared export trimming.
    rgba={l:np.full((*v.shape,4),255,np.uint8) for l,v in arrays.items()}
    for l,v in arrays.items(): rgba[l][...,3]=v
    np.savez_compressed(out,**rgba)
    for l,v in arrays.items():
        active=np.flatnonzero(v.max((1,2))); print(l,'last visible',active[-1],'edge max',max(v[:,0,:].max(),v[:,-1,:].max(),v[:,:,0].max(),v[:,:,-1].max()))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('output',type=Path);a=p.parse_args();main(a.source,a.output)
